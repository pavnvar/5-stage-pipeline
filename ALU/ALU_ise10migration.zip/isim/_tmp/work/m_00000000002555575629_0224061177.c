/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                         */
/*  \   \        Copyright (c) 2003-2007 Xilinx, Inc.                 */
/*  /   /        All Right Reserved.                                  */
/* /---/   /\                                                         */
/* \   \  /  \                                                        */
/*  \___\/\___\                                                       */
/**********************************************************************/

/* This file is designed for use with ISim build 0x734844ce */

#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static int ng0[] = {1, 0};
static int ng1[] = {63, 0};
static unsigned int ng2[] = {1U, 0U, 0U, 0U};
static int ng3[] = {0, 0};
static unsigned int ng4[] = {0U, 0U, 0U, 0U};
static unsigned int ng5[] = {2U, 0U, 0U, 0U};
static unsigned int ng6[] = {4U, 0U, 0U, 0U};



static void C46_0(char *t0)
{
    char t3[16];
    char t4[8];
    char t6[8];
    char t22[8];
    char t37[8];
    char t42[8];
    char t58[8];
    char t66[8];
    char t110[16];
    char t111[8];
    char t114[8];
    char t130[8];
    char t144[8];
    char t149[8];
    char t165[8];
    char t173[8];
    char t205[8];
    char t219[16];
    char t220[8];
    char t228[8];
    char t276[16];
    char t277[8];
    char t280[8];
    char t296[8];
    char t310[16];
    char t311[8];
    char t319[8];
    char *t1;
    char *t2;
    char *t5;
    char *t7;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    char *t23;
    char *t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    char *t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    char *t35;
    char *t36;
    char *t38;
    char *t39;
    char *t40;
    char *t41;
    char *t43;
    char *t44;
    char *t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    char *t59;
    char *t60;
    unsigned int t61;
    unsigned int t62;
    unsigned int t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t67;
    unsigned int t68;
    unsigned int t69;
    char *t70;
    char *t71;
    char *t72;
    unsigned int t73;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    unsigned int t79;
    char *t80;
    char *t81;
    unsigned int t82;
    unsigned int t83;
    unsigned int t84;
    int t85;
    unsigned int t86;
    unsigned int t87;
    unsigned int t88;
    int t89;
    unsigned int t90;
    unsigned int t91;
    unsigned int t92;
    unsigned int t93;
    char *t94;
    char *t95;
    unsigned int t96;
    unsigned int t97;
    unsigned int t98;
    unsigned int t99;
    unsigned int t100;
    char *t101;
    unsigned int t102;
    unsigned int t103;
    unsigned int t104;
    char *t105;
    unsigned int t106;
    unsigned int t107;
    unsigned int t108;
    unsigned int t109;
    char *t112;
    char *t113;
    char *t115;
    char *t116;
    char *t117;
    unsigned int t118;
    unsigned int t119;
    unsigned int t120;
    unsigned int t121;
    unsigned int t122;
    unsigned int t123;
    unsigned int t124;
    unsigned int t125;
    unsigned int t126;
    unsigned int t127;
    unsigned int t128;
    unsigned int t129;
    char *t131;
    char *t132;
    unsigned int t133;
    unsigned int t134;
    unsigned int t135;
    unsigned int t136;
    unsigned int t137;
    char *t138;
    unsigned int t139;
    unsigned int t140;
    unsigned int t141;
    char *t142;
    char *t143;
    char *t145;
    char *t146;
    char *t147;
    char *t148;
    char *t150;
    char *t151;
    char *t152;
    unsigned int t153;
    unsigned int t154;
    unsigned int t155;
    unsigned int t156;
    unsigned int t157;
    unsigned int t158;
    unsigned int t159;
    unsigned int t160;
    unsigned int t161;
    unsigned int t162;
    unsigned int t163;
    unsigned int t164;
    char *t166;
    char *t167;
    unsigned int t168;
    unsigned int t169;
    unsigned int t170;
    unsigned int t171;
    unsigned int t172;
    unsigned int t174;
    unsigned int t175;
    unsigned int t176;
    char *t177;
    char *t178;
    char *t179;
    unsigned int t180;
    unsigned int t181;
    unsigned int t182;
    unsigned int t183;
    unsigned int t184;
    unsigned int t185;
    unsigned int t186;
    char *t187;
    char *t188;
    unsigned int t189;
    unsigned int t190;
    unsigned int t191;
    unsigned int t192;
    unsigned int t193;
    unsigned int t194;
    unsigned int t195;
    unsigned int t196;
    int t197;
    int t198;
    unsigned int t199;
    unsigned int t200;
    unsigned int t201;
    unsigned int t202;
    unsigned int t203;
    unsigned int t204;
    char *t206;
    char *t207;
    unsigned int t208;
    unsigned int t209;
    unsigned int t210;
    unsigned int t211;
    unsigned int t212;
    char *t213;
    unsigned int t214;
    unsigned int t215;
    unsigned int t216;
    char *t217;
    char *t218;
    char *t221;
    char *t222;
    unsigned int t223;
    unsigned int t224;
    unsigned int t225;
    unsigned int t226;
    unsigned int t227;
    unsigned int t229;
    unsigned int t230;
    unsigned int t231;
    char *t232;
    char *t233;
    char *t234;
    unsigned int t235;
    unsigned int t236;
    unsigned int t237;
    unsigned int t238;
    unsigned int t239;
    unsigned int t240;
    unsigned int t241;
    char *t242;
    char *t243;
    unsigned int t244;
    unsigned int t245;
    unsigned int t246;
    unsigned int t247;
    unsigned int t248;
    unsigned int t249;
    unsigned int t250;
    unsigned int t251;
    int t252;
    int t253;
    unsigned int t254;
    unsigned int t255;
    unsigned int t256;
    unsigned int t257;
    unsigned int t258;
    unsigned int t259;
    char *t260;
    char *t261;
    unsigned int t262;
    unsigned int t263;
    unsigned int t264;
    unsigned int t265;
    unsigned int t266;
    char *t267;
    unsigned int t268;
    unsigned int t269;
    unsigned int t270;
    char *t271;
    unsigned int t272;
    unsigned int t273;
    unsigned int t274;
    unsigned int t275;
    char *t278;
    char *t279;
    char *t281;
    char *t282;
    char *t283;
    unsigned int t284;
    unsigned int t285;
    unsigned int t286;
    unsigned int t287;
    unsigned int t288;
    unsigned int t289;
    unsigned int t290;
    unsigned int t291;
    unsigned int t292;
    unsigned int t293;
    unsigned int t294;
    unsigned int t295;
    char *t297;
    char *t298;
    unsigned int t299;
    unsigned int t300;
    unsigned int t301;
    unsigned int t302;
    unsigned int t303;
    char *t304;
    unsigned int t305;
    unsigned int t306;
    unsigned int t307;
    char *t308;
    char *t309;
    char *t312;
    char *t313;
    unsigned int t314;
    unsigned int t315;
    unsigned int t316;
    unsigned int t317;
    unsigned int t318;
    unsigned int t320;
    unsigned int t321;
    unsigned int t322;
    char *t323;
    char *t324;
    char *t325;
    unsigned int t326;
    unsigned int t327;
    unsigned int t328;
    unsigned int t329;
    unsigned int t330;
    unsigned int t331;
    unsigned int t332;
    char *t333;
    char *t334;
    unsigned int t335;
    unsigned int t336;
    unsigned int t337;
    unsigned int t338;
    unsigned int t339;
    unsigned int t340;
    unsigned int t341;
    unsigned int t342;
    int t343;
    int t344;
    unsigned int t345;
    unsigned int t346;
    unsigned int t347;
    unsigned int t348;
    unsigned int t349;
    unsigned int t350;
    char *t351;
    char *t352;
    unsigned int t353;
    unsigned int t354;
    unsigned int t355;
    unsigned int t356;
    unsigned int t357;
    char *t358;
    unsigned int t359;
    unsigned int t360;
    unsigned int t361;
    char *t362;
    unsigned int t363;
    unsigned int t364;
    unsigned int t365;
    unsigned int t366;
    char *t367;
    char *t368;
    char *t369;
    char *t370;
    char *t371;
    char *t372;
    char *t373;

LAB0:    t1 = (t0 + 1612U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 916U);
    t5 = *((char **)t2);
    t2 = ((char*)((ng0)));
    memset(t6, 0, 8);
    t7 = (t6 + 4U);
    t8 = (t5 + 4U);
    t9 = (t2 + 4U);
    t10 = *((unsigned int *)t5);
    t11 = *((unsigned int *)t2);
    t12 = (t10 ^ t11);
    t13 = *((unsigned int *)t8);
    t14 = *((unsigned int *)t9);
    t15 = (t13 ^ t14);
    t16 = (t12 | t15);
    t17 = *((unsigned int *)t8);
    t18 = *((unsigned int *)t9);
    t19 = (t17 | t18);
    t20 = (~(t19));
    t21 = (t16 & t20);
    if (t21 != 0)
        goto LAB7;

LAB4:    if (t19 != 0)
        goto LAB6;

LAB5:    *((unsigned int *)t6) = 1;

LAB7:    memset(t22, 0, 8);
    t23 = (t22 + 4U);
    t24 = (t6 + 4U);
    t25 = *((unsigned int *)t24);
    t26 = (~(t25));
    t27 = *((unsigned int *)t6);
    t28 = (t27 & t26);
    t29 = (t28 & 1U);
    if (t29 != 0)
        goto LAB8;

LAB9:    if (*((unsigned int *)t24) != 0)
        goto LAB10;

LAB11:    t30 = (t22 + 4U);
    t31 = *((unsigned int *)t22);
    t32 = (!(t31));
    t33 = *((unsigned int *)t30);
    t34 = (t32 || t33);
    if (t34 > 0)
        goto LAB12;

LAB13:    memcpy(t66, t22, 8);

LAB14:    memset(t4, 0, 8);
    t94 = (t4 + 4U);
    t95 = (t66 + 4U);
    t96 = *((unsigned int *)t95);
    t97 = (~(t96));
    t98 = *((unsigned int *)t66);
    t99 = (t98 & t97);
    t100 = (t99 & 1U);
    if (t100 != 0)
        goto LAB26;

LAB27:    if (*((unsigned int *)t95) != 0)
        goto LAB28;

LAB29:    t101 = (t4 + 4U);
    t102 = *((unsigned int *)t4);
    t103 = *((unsigned int *)t101);
    t104 = (t102 || t103);
    if (t104 > 0)
        goto LAB30;

LAB31:    t106 = *((unsigned int *)t4);
    t107 = (~(t106));
    t108 = *((unsigned int *)t101);
    t109 = (t107 || t108);
    if (t109 > 0)
        goto LAB32;

LAB33:    if (*((unsigned int *)t101) > 0)
        goto LAB34;

LAB35:    if (*((unsigned int *)t4) > 0)
        goto LAB36;

LAB37:    memcpy(t3, t110, 16);

LAB38:    t368 = (t0 + 1836);
    t369 = (t368 + 32U);
    t370 = *((char **)t369);
    t371 = (t370 + 40U);
    t372 = *((char **)t371);
    xsi_vlog_bit_copy(t372, 0, t3, 0, 64);
    xsi_driver_vfirst_trans(t368, 0, 63);
    t373 = (t0 + 1792);
    *((int *)t373) = 1;

LAB1:    return;
LAB6:    *((unsigned int *)t6) = 1;
    *((unsigned int *)t7) = 1;
    goto LAB7;

LAB8:    *((unsigned int *)t22) = 1;
    goto LAB11;

LAB10:    *((unsigned int *)t22) = 1;
    *((unsigned int *)t23) = 1;
    goto LAB11;

LAB12:    t35 = (t0 + 828U);
    t36 = *((char **)t35);
    t35 = (t0 + 808U);
    t38 = (t35 + 40U);
    t39 = *((char **)t38);
    t40 = ((char*)((ng1)));
    xsi_vlog_generic_get_index_select_value(t37, 32, t36, t39, 2, t40, 32, 1);
    t41 = ((char*)((ng0)));
    memset(t42, 0, 8);
    t43 = (t42 + 4U);
    t44 = (t37 + 4U);
    t45 = (t41 + 4U);
    t46 = *((unsigned int *)t37);
    t47 = *((unsigned int *)t41);
    t48 = (t46 ^ t47);
    t49 = *((unsigned int *)t44);
    t50 = *((unsigned int *)t45);
    t51 = (t49 ^ t50);
    t52 = (t48 | t51);
    t53 = *((unsigned int *)t44);
    t54 = *((unsigned int *)t45);
    t55 = (t53 | t54);
    t56 = (~(t55));
    t57 = (t52 & t56);
    if (t57 != 0)
        goto LAB18;

LAB15:    if (t55 != 0)
        goto LAB17;

LAB16:    *((unsigned int *)t42) = 1;

LAB18:    memset(t58, 0, 8);
    t59 = (t58 + 4U);
    t60 = (t42 + 4U);
    t61 = *((unsigned int *)t60);
    t62 = (~(t61));
    t63 = *((unsigned int *)t42);
    t64 = (t63 & t62);
    t65 = (t64 & 1U);
    if (t65 != 0)
        goto LAB19;

LAB20:    if (*((unsigned int *)t60) != 0)
        goto LAB21;

LAB22:    t67 = *((unsigned int *)t22);
    t68 = *((unsigned int *)t58);
    t69 = (t67 | t68);
    *((unsigned int *)t66) = t69;
    t70 = (t22 + 4U);
    t71 = (t58 + 4U);
    t72 = (t66 + 4U);
    t73 = *((unsigned int *)t70);
    t74 = *((unsigned int *)t71);
    t75 = (t73 | t74);
    *((unsigned int *)t72) = t75;
    t76 = *((unsigned int *)t72);
    t77 = (t76 != 0);
    if (t77 == 1)
        goto LAB23;

LAB24:
LAB25:    goto LAB14;

LAB17:    *((unsigned int *)t42) = 1;
    *((unsigned int *)t43) = 1;
    goto LAB18;

LAB19:    *((unsigned int *)t58) = 1;
    goto LAB22;

LAB21:    *((unsigned int *)t58) = 1;
    *((unsigned int *)t59) = 1;
    goto LAB22;

LAB23:    t78 = *((unsigned int *)t66);
    t79 = *((unsigned int *)t72);
    *((unsigned int *)t66) = (t78 | t79);
    t80 = (t22 + 4U);
    t81 = (t58 + 4U);
    t82 = *((unsigned int *)t80);
    t83 = (~(t82));
    t84 = *((unsigned int *)t22);
    t85 = (t84 & t83);
    t86 = *((unsigned int *)t81);
    t87 = (~(t86));
    t88 = *((unsigned int *)t58);
    t89 = (t88 & t87);
    t90 = (~(t85));
    t91 = (~(t89));
    t92 = *((unsigned int *)t72);
    *((unsigned int *)t72) = (t92 & t90);
    t93 = *((unsigned int *)t72);
    *((unsigned int *)t72) = (t93 & t91);
    goto LAB25;

LAB26:    *((unsigned int *)t4) = 1;
    goto LAB29;

LAB28:    *((unsigned int *)t4) = 1;
    *((unsigned int *)t94) = 1;
    goto LAB29;

LAB30:    t105 = ((char*)((ng2)));
    goto LAB31;

LAB32:    t112 = (t0 + 916U);
    t113 = *((char **)t112);
    t112 = ((char*)((ng3)));
    memset(t114, 0, 8);
    t115 = (t114 + 4U);
    t116 = (t113 + 4U);
    t117 = (t112 + 4U);
    t118 = *((unsigned int *)t113);
    t119 = *((unsigned int *)t112);
    t120 = (t118 ^ t119);
    t121 = *((unsigned int *)t116);
    t122 = *((unsigned int *)t117);
    t123 = (t121 ^ t122);
    t124 = (t120 | t123);
    t125 = *((unsigned int *)t116);
    t126 = *((unsigned int *)t117);
    t127 = (t125 | t126);
    t128 = (~(t127));
    t129 = (t124 & t128);
    if (t129 != 0)
        goto LAB42;

LAB39:    if (t127 != 0)
        goto LAB41;

LAB40:    *((unsigned int *)t114) = 1;

LAB42:    memset(t130, 0, 8);
    t131 = (t130 + 4U);
    t132 = (t114 + 4U);
    t133 = *((unsigned int *)t132);
    t134 = (~(t133));
    t135 = *((unsigned int *)t114);
    t136 = (t135 & t134);
    t137 = (t136 & 1U);
    if (t137 != 0)
        goto LAB43;

LAB44:    if (*((unsigned int *)t132) != 0)
        goto LAB45;

LAB46:    t138 = (t130 + 4U);
    t139 = *((unsigned int *)t130);
    t140 = *((unsigned int *)t138);
    t141 = (t139 || t140);
    if (t141 > 0)
        goto LAB47;

LAB48:    memcpy(t173, t130, 8);

LAB49:    memset(t205, 0, 8);
    t206 = (t205 + 4U);
    t207 = (t173 + 4U);
    t208 = *((unsigned int *)t207);
    t209 = (~(t208));
    t210 = *((unsigned int *)t173);
    t211 = (t210 & t209);
    t212 = (t211 & 1U);
    if (t212 != 0)
        goto LAB61;

LAB62:    if (*((unsigned int *)t207) != 0)
        goto LAB63;

LAB64:    t213 = (t205 + 4U);
    t214 = *((unsigned int *)t205);
    t215 = *((unsigned int *)t213);
    t216 = (t214 || t215);
    if (t216 > 0)
        goto LAB65;

LAB66:    memcpy(t228, t205, 8);

LAB67:    memset(t111, 0, 8);
    t260 = (t111 + 4U);
    t261 = (t228 + 4U);
    t262 = *((unsigned int *)t261);
    t263 = (~(t262));
    t264 = *((unsigned int *)t228);
    t265 = (t264 & t263);
    t266 = (t265 & 1U);
    if (t266 != 0)
        goto LAB75;

LAB76:    if (*((unsigned int *)t261) != 0)
        goto LAB77;

LAB78:    t267 = (t111 + 4U);
    t268 = *((unsigned int *)t111);
    t269 = *((unsigned int *)t267);
    t270 = (t268 || t269);
    if (t270 > 0)
        goto LAB79;

LAB80:    t272 = *((unsigned int *)t111);
    t273 = (~(t272));
    t274 = *((unsigned int *)t267);
    t275 = (t273 || t274);
    if (t275 > 0)
        goto LAB81;

LAB82:    if (*((unsigned int *)t267) > 0)
        goto LAB83;

LAB84:    if (*((unsigned int *)t111) > 0)
        goto LAB85;

LAB86:    memcpy(t110, t276, 16);

LAB87:    goto LAB33;

LAB34:    xsi_vlog_unsigned_bit_combine(t3, 64, t105, 64, t110, 64);
    goto LAB38;

LAB36:    memcpy(t3, t105, 16);
    goto LAB38;

LAB41:    *((unsigned int *)t114) = 1;
    *((unsigned int *)t115) = 1;
    goto LAB42;

LAB43:    *((unsigned int *)t130) = 1;
    goto LAB46;

LAB45:    *((unsigned int *)t130) = 1;
    *((unsigned int *)t131) = 1;
    goto LAB46;

LAB47:    t142 = (t0 + 828U);
    t143 = *((char **)t142);
    t142 = (t0 + 808U);
    t145 = (t142 + 40U);
    t146 = *((char **)t145);
    t147 = ((char*)((ng1)));
    xsi_vlog_generic_get_index_select_value(t144, 32, t143, t146, 2, t147, 32, 1);
    t148 = ((char*)((ng3)));
    memset(t149, 0, 8);
    t150 = (t149 + 4U);
    t151 = (t144 + 4U);
    t152 = (t148 + 4U);
    t153 = *((unsigned int *)t144);
    t154 = *((unsigned int *)t148);
    t155 = (t153 ^ t154);
    t156 = *((unsigned int *)t151);
    t157 = *((unsigned int *)t152);
    t158 = (t156 ^ t157);
    t159 = (t155 | t158);
    t160 = *((unsigned int *)t151);
    t161 = *((unsigned int *)t152);
    t162 = (t160 | t161);
    t163 = (~(t162));
    t164 = (t159 & t163);
    if (t164 != 0)
        goto LAB53;

LAB50:    if (t162 != 0)
        goto LAB52;

LAB51:    *((unsigned int *)t149) = 1;

LAB53:    memset(t165, 0, 8);
    t166 = (t165 + 4U);
    t167 = (t149 + 4U);
    t168 = *((unsigned int *)t167);
    t169 = (~(t168));
    t170 = *((unsigned int *)t149);
    t171 = (t170 & t169);
    t172 = (t171 & 1U);
    if (t172 != 0)
        goto LAB54;

LAB55:    if (*((unsigned int *)t167) != 0)
        goto LAB56;

LAB57:    t174 = *((unsigned int *)t130);
    t175 = *((unsigned int *)t165);
    t176 = (t174 & t175);
    *((unsigned int *)t173) = t176;
    t177 = (t130 + 4U);
    t178 = (t165 + 4U);
    t179 = (t173 + 4U);
    t180 = *((unsigned int *)t177);
    t181 = *((unsigned int *)t178);
    t182 = (t180 | t181);
    *((unsigned int *)t179) = t182;
    t183 = *((unsigned int *)t179);
    t184 = (t183 != 0);
    if (t184 == 1)
        goto LAB58;

LAB59:
LAB60:    goto LAB49;

LAB52:    *((unsigned int *)t149) = 1;
    *((unsigned int *)t150) = 1;
    goto LAB53;

LAB54:    *((unsigned int *)t165) = 1;
    goto LAB57;

LAB56:    *((unsigned int *)t165) = 1;
    *((unsigned int *)t166) = 1;
    goto LAB57;

LAB58:    t185 = *((unsigned int *)t173);
    t186 = *((unsigned int *)t179);
    *((unsigned int *)t173) = (t185 | t186);
    t187 = (t130 + 4U);
    t188 = (t165 + 4U);
    t189 = *((unsigned int *)t130);
    t190 = (~(t189));
    t191 = *((unsigned int *)t187);
    t192 = (~(t191));
    t193 = *((unsigned int *)t165);
    t194 = (~(t193));
    t195 = *((unsigned int *)t188);
    t196 = (~(t195));
    t197 = (t190 & t192);
    t198 = (t194 & t196);
    t199 = (~(t197));
    t200 = (~(t198));
    t201 = *((unsigned int *)t179);
    *((unsigned int *)t179) = (t201 & t199);
    t202 = *((unsigned int *)t179);
    *((unsigned int *)t179) = (t202 & t200);
    t203 = *((unsigned int *)t173);
    *((unsigned int *)t173) = (t203 & t199);
    t204 = *((unsigned int *)t173);
    *((unsigned int *)t173) = (t204 & t200);
    goto LAB60;

LAB61:    *((unsigned int *)t205) = 1;
    goto LAB64;

LAB63:    *((unsigned int *)t205) = 1;
    *((unsigned int *)t206) = 1;
    goto LAB64;

LAB65:    t217 = (t0 + 828U);
    t218 = *((char **)t217);
    t217 = ((char*)((ng4)));
    xsi_vlog_unsigned_not_equal(t219, 64, t218, 64, t217, 64);
    memset(t220, 0, 8);
    t221 = (t220 + 4U);
    t222 = (t219 + 4U);
    t223 = *((unsigned int *)t222);
    t224 = (~(t223));
    t225 = *((unsigned int *)t219);
    t226 = (t225 & t224);
    t227 = (t226 & 1U);
    if (t227 != 0)
        goto LAB68;

LAB69:    if (*((unsigned int *)t222) != 0)
        goto LAB70;

LAB71:    t229 = *((unsigned int *)t205);
    t230 = *((unsigned int *)t220);
    t231 = (t229 & t230);
    *((unsigned int *)t228) = t231;
    t232 = (t205 + 4U);
    t233 = (t220 + 4U);
    t234 = (t228 + 4U);
    t235 = *((unsigned int *)t232);
    t236 = *((unsigned int *)t233);
    t237 = (t235 | t236);
    *((unsigned int *)t234) = t237;
    t238 = *((unsigned int *)t234);
    t239 = (t238 != 0);
    if (t239 == 1)
        goto LAB72;

LAB73:
LAB74:    goto LAB67;

LAB68:    *((unsigned int *)t220) = 1;
    goto LAB71;

LAB70:    *((unsigned int *)t220) = 1;
    *((unsigned int *)t221) = 1;
    goto LAB71;

LAB72:    t240 = *((unsigned int *)t228);
    t241 = *((unsigned int *)t234);
    *((unsigned int *)t228) = (t240 | t241);
    t242 = (t205 + 4U);
    t243 = (t220 + 4U);
    t244 = *((unsigned int *)t205);
    t245 = (~(t244));
    t246 = *((unsigned int *)t242);
    t247 = (~(t246));
    t248 = *((unsigned int *)t220);
    t249 = (~(t248));
    t250 = *((unsigned int *)t243);
    t251 = (~(t250));
    t252 = (t245 & t247);
    t253 = (t249 & t251);
    t254 = (~(t252));
    t255 = (~(t253));
    t256 = *((unsigned int *)t234);
    *((unsigned int *)t234) = (t256 & t254);
    t257 = *((unsigned int *)t234);
    *((unsigned int *)t234) = (t257 & t255);
    t258 = *((unsigned int *)t228);
    *((unsigned int *)t228) = (t258 & t254);
    t259 = *((unsigned int *)t228);
    *((unsigned int *)t228) = (t259 & t255);
    goto LAB74;

LAB75:    *((unsigned int *)t111) = 1;
    goto LAB78;

LAB77:    *((unsigned int *)t111) = 1;
    *((unsigned int *)t260) = 1;
    goto LAB78;

LAB79:    t271 = ((char*)((ng5)));
    goto LAB80;

LAB81:    t278 = (t0 + 916U);
    t279 = *((char **)t278);
    t278 = ((char*)((ng3)));
    memset(t280, 0, 8);
    t281 = (t280 + 4U);
    t282 = (t279 + 4U);
    t283 = (t278 + 4U);
    t284 = *((unsigned int *)t279);
    t285 = *((unsigned int *)t278);
    t286 = (t284 ^ t285);
    t287 = *((unsigned int *)t282);
    t288 = *((unsigned int *)t283);
    t289 = (t287 ^ t288);
    t290 = (t286 | t289);
    t291 = *((unsigned int *)t282);
    t292 = *((unsigned int *)t283);
    t293 = (t291 | t292);
    t294 = (~(t293));
    t295 = (t290 & t294);
    if (t295 != 0)
        goto LAB91;

LAB88:    if (t293 != 0)
        goto LAB90;

LAB89:    *((unsigned int *)t280) = 1;

LAB91:    memset(t296, 0, 8);
    t297 = (t296 + 4U);
    t298 = (t280 + 4U);
    t299 = *((unsigned int *)t298);
    t300 = (~(t299));
    t301 = *((unsigned int *)t280);
    t302 = (t301 & t300);
    t303 = (t302 & 1U);
    if (t303 != 0)
        goto LAB92;

LAB93:    if (*((unsigned int *)t298) != 0)
        goto LAB94;

LAB95:    t304 = (t296 + 4U);
    t305 = *((unsigned int *)t296);
    t306 = *((unsigned int *)t304);
    t307 = (t305 || t306);
    if (t307 > 0)
        goto LAB96;

LAB97:    memcpy(t319, t296, 8);

LAB98:    memset(t277, 0, 8);
    t351 = (t277 + 4U);
    t352 = (t319 + 4U);
    t353 = *((unsigned int *)t352);
    t354 = (~(t353));
    t355 = *((unsigned int *)t319);
    t356 = (t355 & t354);
    t357 = (t356 & 1U);
    if (t357 != 0)
        goto LAB106;

LAB107:    if (*((unsigned int *)t352) != 0)
        goto LAB108;

LAB109:    t358 = (t277 + 4U);
    t359 = *((unsigned int *)t277);
    t360 = *((unsigned int *)t358);
    t361 = (t359 || t360);
    if (t361 > 0)
        goto LAB110;

LAB111:    t363 = *((unsigned int *)t277);
    t364 = (~(t363));
    t365 = *((unsigned int *)t358);
    t366 = (t364 || t365);
    if (t366 > 0)
        goto LAB112;

LAB113:    if (*((unsigned int *)t358) > 0)
        goto LAB114;

LAB115:    if (*((unsigned int *)t277) > 0)
        goto LAB116;

LAB117:    memcpy(t276, t367, 16);

LAB118:    goto LAB82;

LAB83:    xsi_vlog_unsigned_bit_combine(t110, 64, t271, 64, t276, 64);
    goto LAB87;

LAB85:    memcpy(t110, t271, 16);
    goto LAB87;

LAB90:    *((unsigned int *)t280) = 1;
    *((unsigned int *)t281) = 1;
    goto LAB91;

LAB92:    *((unsigned int *)t296) = 1;
    goto LAB95;

LAB94:    *((unsigned int *)t296) = 1;
    *((unsigned int *)t297) = 1;
    goto LAB95;

LAB96:    t308 = (t0 + 828U);
    t309 = *((char **)t308);
    t308 = ((char*)((ng4)));
    xsi_vlog_unsigned_equal(t310, 64, t309, 64, t308, 64);
    memset(t311, 0, 8);
    t312 = (t311 + 4U);
    t313 = (t310 + 4U);
    t314 = *((unsigned int *)t313);
    t315 = (~(t314));
    t316 = *((unsigned int *)t310);
    t317 = (t316 & t315);
    t318 = (t317 & 1U);
    if (t318 != 0)
        goto LAB99;

LAB100:    if (*((unsigned int *)t313) != 0)
        goto LAB101;

LAB102:    t320 = *((unsigned int *)t296);
    t321 = *((unsigned int *)t311);
    t322 = (t320 & t321);
    *((unsigned int *)t319) = t322;
    t323 = (t296 + 4U);
    t324 = (t311 + 4U);
    t325 = (t319 + 4U);
    t326 = *((unsigned int *)t323);
    t327 = *((unsigned int *)t324);
    t328 = (t326 | t327);
    *((unsigned int *)t325) = t328;
    t329 = *((unsigned int *)t325);
    t330 = (t329 != 0);
    if (t330 == 1)
        goto LAB103;

LAB104:
LAB105:    goto LAB98;

LAB99:    *((unsigned int *)t311) = 1;
    goto LAB102;

LAB101:    *((unsigned int *)t311) = 1;
    *((unsigned int *)t312) = 1;
    goto LAB102;

LAB103:    t331 = *((unsigned int *)t319);
    t332 = *((unsigned int *)t325);
    *((unsigned int *)t319) = (t331 | t332);
    t333 = (t296 + 4U);
    t334 = (t311 + 4U);
    t335 = *((unsigned int *)t296);
    t336 = (~(t335));
    t337 = *((unsigned int *)t333);
    t338 = (~(t337));
    t339 = *((unsigned int *)t311);
    t340 = (~(t339));
    t341 = *((unsigned int *)t334);
    t342 = (~(t341));
    t343 = (t336 & t338);
    t344 = (t340 & t342);
    t345 = (~(t343));
    t346 = (~(t344));
    t347 = *((unsigned int *)t325);
    *((unsigned int *)t325) = (t347 & t345);
    t348 = *((unsigned int *)t325);
    *((unsigned int *)t325) = (t348 & t346);
    t349 = *((unsigned int *)t319);
    *((unsigned int *)t319) = (t349 & t345);
    t350 = *((unsigned int *)t319);
    *((unsigned int *)t319) = (t350 & t346);
    goto LAB105;

LAB106:    *((unsigned int *)t277) = 1;
    goto LAB109;

LAB108:    *((unsigned int *)t277) = 1;
    *((unsigned int *)t351) = 1;
    goto LAB109;

LAB110:    t362 = ((char*)((ng6)));
    goto LAB111;

LAB112:    t367 = ((char*)((ng4)));
    goto LAB113;

LAB114:    xsi_vlog_unsigned_bit_combine(t276, 64, t362, 64, t367, 64);
    goto LAB118;

LAB116:    memcpy(t276, t362, 16);
    goto LAB118;

}


extern void work_m_00000000002555575629_0224061177_init()
{
	static char *pe[] = {(void *)C46_0};
	xsi_register_didat("work_m_00000000002555575629_0224061177", "isim/_tmp/work/m_00000000002555575629_0224061177.didat");
	xsi_register_executes(pe);
}
